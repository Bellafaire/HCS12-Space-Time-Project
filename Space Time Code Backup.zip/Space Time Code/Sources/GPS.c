#include "Declarations.h"  
#include <hidef.h>   
#include "derivative.h"  

//who needs ram? we need strings!
char serialBuffer[512];


//inits UART on the second UART port, configures the uart output to a baud rate of 9600 and enables the interrupt
//to allow for us to buffer incomming data. 
void initUART2(void){
 SCI1BDH = 0x00;
 SCI1BDL = 156; 
 
 SCI1CR1 = 0x00; //8 bit data frame, no parity bit, no loop; 
 
 SCI1CR2 |= (1 << 2); //Recieve Enable 
 SCI1CR2 |= (1 << 5); //Reciever Full Interrupt Enable 
 __asm CLI; //enable global interrupts
}